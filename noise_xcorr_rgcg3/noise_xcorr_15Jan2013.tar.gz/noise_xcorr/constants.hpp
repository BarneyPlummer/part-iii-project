// constants.hpp
// define constants used in multiple programs
#pragma once

#define HOUR_BLOCKS 1
#define DAY_BLOCKS 2

